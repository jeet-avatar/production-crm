-- AlterTable
ALTER TABLE "companies" ADD COLUMN "video_url" TEXT,
ADD COLUMN "pitch" TEXT;
